import java.util.Random;
import java.util.Scanner;

public class JogoDaVelha {

    public static void main(String[] args) {

        Scanner entrada = new Scanner(System.in);
        Random random = new Random();

        String[] tabuleiro = {
            "1", "2", "3",
            "4", "5", "6",
            "7", "8", "9"
        };

        boolean jogoAcabou = false;

        System.out.println("=== JOGO DA VELHA ===");
        System.out.println("Você é X e a máquina é O.");

        while (!jogoAcabou) {

            mostrarTabuleiro(tabuleiro);

            System.out.print("Escolha uma posição (1-9): ");
            int jogador = entrada.nextInt();

            if (jogador < 1 || jogador > 9) {
                System.out.println("Posição inválida!");
                continue;
            }

            if (!tabuleiro[jogador - 1].equals("X") &&
                !tabuleiro[jogador - 1].equals("O")) {

                tabuleiro[jogador - 1] = "X";

            } else {
                System.out.println("Essa posição já está ocupada!");
                continue;
            }

            if (verificarVitoria(tabuleiro, "X")) {
                mostrarTabuleiro(tabuleiro);
                System.out.println("Você venceu!");
                jogoAcabou = true;
                continue;
            }

            if (tabuleiroCheio(tabuleiro)) {
                mostrarTabuleiro(tabuleiro);
                System.out.println("Empate!");
                jogoAcabou = true;
                continue;
            }

            int maquina;

            do {
                maquina = random.nextInt(9);
            } while (tabuleiro[maquina].equals("X") ||
                     tabuleiro[maquina].equals("O"));

            tabuleiro[maquina] = "O";

            System.out.println("A máquina jogou na posição " + (maquina + 1));

            if (verificarVitoria(tabuleiro, "O")) {
                mostrarTabuleiro(tabuleiro);
                System.out.println("A máquina venceu!");
                jogoAcabou = true;
            }

            if (!jogoAcabou && tabuleiroCheio(tabuleiro)) {
                mostrarTabuleiro(tabuleiro);
                System.out.println("Empate!");
                jogoAcabou = true;
            }
        }

        entrada.close();
    }

    public static void mostrarTabuleiro(String[] tabuleiro) {

        System.out.println();
        System.out.println(" " + tabuleiro[0] + " | " + tabuleiro[1] + " | " + tabuleiro[2]);
        System.out.println("---+---+---");
        System.out.println(" " + tabuleiro[3] + " | " + tabuleiro[4] + " | " + tabuleiro[5]);
        System.out.println("---+---+---");
        System.out.println(" " + tabuleiro[6] + " | " + tabuleiro[7] + " | " + tabuleiro[8]);
        System.out.println();
    }

    public static boolean verificarVitoria(String[] tabuleiro, String jogador) {

        int[][] vitorias = {
            {0, 1, 2},
            {3, 4, 5},
            {6, 7, 8},
            {0, 3, 6},
            {1, 4, 7},
            {2, 5, 8},
            {0, 4, 8},
            {2, 4, 6}
        };

        for (int[] combinacao : vitorias) {

            if (tabuleiro[combinacao[0]].equals(jogador) &&
                tabuleiro[combinacao[1]].equals(jogador) &&
                tabuleiro[combinacao[2]].equals(jogador)) {

                return true;
            }
        }

        return false;
    }

    public static boolean tabuleiroCheio(String[] tabuleiro) {

        for (String posicao : tabuleiro) {

            if (!posicao.equals("X") && !posicao.equals("O")) {
                return false;
            }
        }

        return true;
    }
}